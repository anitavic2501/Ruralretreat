<style>
.footer {
   position: inherit;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: grey;
   color: black;
   text-align: center;
}
</style>



<div class="footer" style="width:100%; padding-top: 10px;">
        <div class="col-12">
        <p> © 2019 Rural Retreat,Ltd. | All Rights Reserved | Privacy Policy </p>
        <img src="images/socialmedia.png" width="100px">
        </div>
</div>
