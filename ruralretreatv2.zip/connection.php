    <?php
    include "includes/dbh.inc.php";
    
        // $servername = "ruralretreat.cespegrr14df.ap-southeast-2.rds.amazonaws.com";
        // $username = "root";
        // $password = "123anita";
        // $dbname = "ruralretreat";

        // // Create connection
        // $conn = mysqli_connect($servername, $username, $password, $dbname);
    ?>