<?php

class ErrorMessages{


    public static $NO_MORE_DOGS = "Sorry we cannot accept anymore  dogs for this day. Please choose another date.";
    public static $BOOKING_ERROR = "Sorry an error occured during booking process. Please try again.";
    public static $SAME_DATE_BOOKING= "Sorry you cannot book at the same date! Choose another date.";
    public static $CORRECT_BOOKING_DATE= "Sorry we couldn't create a booking. Reason: End of the booking period should be after a start of the booking period";



}






?>